import { motion } from "framer-motion";

const PageTransition = ({ children }) => {

    return (

        <motion.div

            initial={{
                opacity:0,
                y:20
            }}

            animate={{
                opacity:1,
                y:0
            }}

            exit={{
                opacity:0,
                y:-20
            }}

            transition={{
                duration:.35
            }}

        >

            {children}

        </motion.div>

    );

};

export default PageTransition;