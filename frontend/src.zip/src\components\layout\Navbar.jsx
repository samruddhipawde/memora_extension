import "./Navbar.css";

import { useState } from "react";

import { useNavigate } from "react-router-dom";

import {

Search,

Bell,

Moon,

Plus

} from "lucide-react";

import { useAuth } from "../../context/AuthContext";

import SaveMemoryModal from "../dashboard/SaveMemoryModal";

const Navbar=()=>{

const navigate=useNavigate();

const {user}=useAuth();

const [search,setSearch]=useState("");

const [open,setOpen]=useState(false);

return(

<>

<header className="navbar">

<div className="navbar-left">

<div className="search-box">

<Search size={18}/>

<input

placeholder="Search memories..."

value={search}

onChange={(e)=>setSearch(e.target.value)}

onKeyDown={(e)=>{

if(e.key==="Enter"){

navigate(`/search?q=${search}`);

}

}}

/>

</div>

</div>

<div className="navbar-right">

<button

className="save-btn"

onClick={()=>setOpen(true)}

>

<Plus size={18}/>

Save Memory

</button>

<button className="nav-icon">

<Bell size={18}/>

</button>

<button className="nav-icon">

<Moon size={18}/>

</button>

<div className="profile-box">

<div className="avatar">

{user?.full_name?.charAt(0) || "M"}

</div>

<div>

<h4>{user?.full_name}</h4>

<span>{user?.email}</span>

</div>

</div>

</div>

</header>

<SaveMemoryModal

open={open}

onClose={()=>setOpen(false)}

onSaved={()=>window.location.reload()}

/>

</>

);

};

export default Navbar;