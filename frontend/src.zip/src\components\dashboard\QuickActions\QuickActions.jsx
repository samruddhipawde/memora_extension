import "./QuickActions.css";

import { useNavigate } from "react-router-dom";

import {
  Save,
  Search,
  FolderKanban,
  MessageCircle,
} from "lucide-react";

const QuickActions = () => {

  const navigate = useNavigate();

  const actions = [

    {
      title: "Save Memory",
      icon: <Save size={28} />,
      color: "#8B5CF6",
      path: "#save",
    },

    {
      title: "Semantic Search",
      icon: <Search size={28} />,
      color: "#2563EB",
      path: "/search",
    },

    {
      title: "Collections",
      icon: <FolderKanban size={28} />,
      color: "#06B6D4",
      path: "/collections",
    },

    {
      title: "AI Chat",
      icon: <MessageCircle size={28} />,
      color: "#10B981",
      path: "/chat",
    },

  ];

  const handleClick = (action) => {

    if (action.path === "#save") {

      document.querySelector(".save-btn")?.click();

      return;

    }

    navigate(action.path);

  };

  return (

    <div className="quick-actions">

      {

        actions.map((action) => (

          <div

            key={action.title}

            className="quick-card"

            onClick={() => handleClick(action)}

          >

            <div

              className="icon"

              style={{
                background: action.color,
              }}

            >

              {action.icon}

            </div>

            <h3>

              {action.title}

            </h3>

          </div>

        ))

      }

    </div>

  );

};

export default QuickActions;